package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Book_Lab_Activity extends AppCompatActivity {
    TextView set_leb_name,set_leb_amo;
    TextView username_2,email_2,contect_2;

    Button btn_book_now;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_lab);

        set_leb_name=findViewById(R.id.set_leb_name);
        set_leb_amo=findViewById(R.id.set_leb_amo);
        username_2=findViewById(R.id.username_2);
        email_2=findViewById(R.id.email_2);
        contect_2=findViewById(R.id.contect_2);

        btn_book_now=findViewById(R.id.btn_book_now);

        Intent intent=getIntent();
        String getset_leb_name = intent.getStringExtra("set_leb_name");
        String getset_leb_amo = intent.getStringExtra("set_leb_amo");
        String getusername_2 = intent.getStringExtra("username_2");
        String getemail_2 = intent.getStringExtra("email_2");
        String getcontect_2= intent.getStringExtra("contect_2");

        String getbtn_book_now=intent.getStringExtra("btn_book_now");

        set_leb_name.setText(getset_leb_name);
        set_leb_amo.setText(getset_leb_amo);
        username_2.setText(getusername_2);
        email_2.setText(getemail_2);
        contect_2.setText(getcontect_2);
        btn_book_now.setText(getbtn_book_now);

    }
}
