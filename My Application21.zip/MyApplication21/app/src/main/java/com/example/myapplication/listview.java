package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class listview extends AppCompatActivity {

    String[] course={"c++","java","js","kotlin"};
    ListView listView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listview);

        listView =findViewById(R.id.listview);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(listview.this, android.R.layout.simple_dropdown_item_1line,course);
        listView.setAdapter(adapter);


    }



}